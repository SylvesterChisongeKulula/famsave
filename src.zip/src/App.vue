<template>
  <div class="h-screen bg-gray-100">
    <router-view/>
  </div>
</template>